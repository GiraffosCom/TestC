Theme ALan
---------------


Steps for installation :
----------------------------

Download theme_alan module
Go to theme_alan/code folder
Cut alan_customize folder and move these folder into your addons path 
Go to apps and update applist.
Click on install theme_alan
After install this module you will redirect to choose theme for your website page.


