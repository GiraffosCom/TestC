
=====
Theme Installation guide
=====

1. Download theme_alan module

2. Go to theme_alan/code folder

3. Cut alan_customize folder and move these folder into your addons path 

4. Open theme_alan folder __manifest__.py file

5. Replace 'depends': [''website_theme_install'] line with 'depends': ['alan_customize','website_theme_install']

6. Go to apps and update applist.

7. Click on install theme_alan.

8. After install this module you will redirect to choose theme for your website page.

